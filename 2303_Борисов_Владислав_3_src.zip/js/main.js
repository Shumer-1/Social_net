import './addUser.js';
import './friends.js';
import './news.js';
import './userList.js';
